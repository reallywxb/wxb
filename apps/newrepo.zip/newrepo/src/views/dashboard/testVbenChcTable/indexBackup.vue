<script setup lang="ts">
import type { VxeGridProps } from '#/adapter/vxe-table';

import { reactive } from 'vue';

import { Page } from '@vben/common-ui';

import { Button } from 'ant-design-vue';

import { VxeGrid } from '#/adapter/vxe-table';
// import { VbenChcTable } from '#/adapter/vxe-table.js';
const gridOptions = reactive<VxeGridProps<any>>({
  border: true,
  showOverflow: true,
  height: 'auto',
  keepSource: true,
  mouseConfig: {
    selected: true,
  },
  keyboardConfig: {
    isEdit: true,
    isArrow: true,
    isEnter: true,
    isTab: true,
    isDel: true,
    isBack: true,
    isEsc: true,
  },
  editConfig: {
    trigger: 'dblclick',
    mode: 'cell',
  },
  columns: [
    { type: 'checkbox', width: 70 },
    { type: 'seq', width: 70 },
    { field: 'name', title: 'Name', editRender: { name: 'VxeInput' } },
    { field: 'sex', title: 'Sex', editRender: { name: 'VxeInput' } },
    { field: 'age', title: 'Age', editRender: { name: 'VxeInput' } },
    {
      field: 'action',
      title: '操作',
      width: 140,
      slots: { default: 'action' },
    },
  ],
  data: [
    {
      id: 10_001,
      name: 'Test1',
      role: 'Develop',
      sex: 'Man',
      age: 28,
      address: 'test abc',
    },
    {
      id: 10_002,
      name: 'Test2',
      role: 'Test',
      sex: 'Women',
      age: 22,
      address: 'Guangzhou',
    },
    {
      id: 10_003,
      name: 'Test3',
      role: 'PM',
      sex: 'Man',
      age: 32,
      address: 'Shanghai',
    },
    {
      id: 10_004,
      name: 'Test4',
      role: 'Designer',
      sex: 'Women',
      age: 23,
      address: 'test abc',
    },
    {
      id: 10_005,
      name: 'Test5',
      role: 'Develop',
      sex: 'Women',
      age: 30,
      address: 'Shanghai',
    },
    {
      id: 10_006,
      name: 'Test6',
      role: 'Designer',
      sex: 'Women',
      age: 21,
      address: 'test abc',
    },
    {
      id: 10_007,
      name: 'Test7',
      role: 'Test',
      sex: 'Man',
      age: 29,
      address: 'test abc',
    },
    {
      id: 10_008,
      name: 'Test8',
      role: 'Develop',
      sex: 'Man',
      age: 35,
      address: 'test abc',
    },
    {
      id: 10_009,
      name: 'Test9',
      role: 'Test',
      sex: 'Man',
      age: 26,
      address: 'test abc',
    },
    {
      id: 10_010,
      name: 'Test10',
      role: 'Develop',
      sex: 'Man',
      age: 38,
      address: 'test abc',
    },
    {
      id: 10_011,
      name: 'Test11',
      role: 'Test',
      sex: 'Women',
      age: 29,
      address: 'test abc',
    },
    {
      id: 10_012,
      name: 'Test12',
      role: 'Develop',
      sex: 'Man',
      age: 27,
      address: 'test abc',
    },
    {
      id: 10_013,
      name: 'Test13',
      role: 'Test',
      sex: 'Women',
      age: 24,
      address: 'test abc',
    },
    {
      id: 10_014,
      name: 'Test14',
      role: 'Develop',
      sex: 'Man',
      age: 34,
      address: 'test abc',
    },
    {
      id: 10_015,
      name: 'Test15',
      role: 'Test',
      sex: 'Man',
      age: 21,
      address: 'test abc',
    },
    {
      id: 10_016,
      name: 'Test16',
      role: 'Develop',
      sex: 'Women',
      age: 20,
      address: 'test abc',
    },
    {
      id: 10_017,
      name: 'Test17',
      role: 'Test',
      sex: 'Man',
      age: 31,
      address: 'test abc',
    },
    {
      id: 10_018,
      name: 'Test18',
      role: 'Develop',
      sex: 'Women',
      age: 32,
      address: 'test abc',
    },
    {
      id: 10_019,
      name: 'Test19',
      role: 'Test',
      sex: 'Man',
      age: 37,
      address: 'test abc',
    },
    {
      id: 10_020,
      name: 'Test20',
      role: 'Develop',
      sex: 'Man',
      age: 41,
      address: 'test abc',
    },
  ],
});
function handleChangeOption() {
  gridOptions.border = !gridOptions.border;
  gridOptions.columns = [
    { type: 'checkbox', width: 70 },
    { type: 'seq', width: 70 },
    { field: 'name', title: 'Name', editRender: { name: 'VxeInput' } },
    { field: 'sex', title: 'Sex', editRender: { name: 'VxeInput' } },
    { field: 'age', title: 'Age', editRender: { name: 'VxeInput' } },
    {
      field: 'action',
      title: '操作',
      width: 140,
      slots: { default: 'action' },
    },
  ];
}
</script>
<template>
  <Page auto-content-height content-class="p-[0.5rem]" header-class="px-3 py-2">
    <VxeGrid v-bind="gridOptions" class="h-full">
      <template #action>
        <Button @click="handleChangeOption">1232</Button>
      </template>
    </VxeGrid>
  </Page>
</template>
<style scoped></style>
